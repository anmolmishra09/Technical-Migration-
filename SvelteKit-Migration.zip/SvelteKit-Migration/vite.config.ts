import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';
import path from 'path';

export default defineConfig({
	plugins: [sveltekit()],
    resolve: {
        alias: {
            "@": path.resolve(process.cwd(), "client", "src"),
            "@shared": path.resolve(process.cwd(), "shared"),
        }
    },
    server: {
        host: '0.0.0.0',
        port: 5000,
        allowedHosts: true
    }
});
