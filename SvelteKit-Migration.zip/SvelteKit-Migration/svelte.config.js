import adapter from '@sveltejs/adapter-node';
import { vitePreprocess } from '@sveltejs/vite-plugin-svelte';

/** @type {import('@sveltejs/kit').Config} */
const config = {
	preprocess: vitePreprocess(),
	kit: {
		adapter: adapter(),
        files: {
            assets: 'client/public',
            hooks: {
                client: 'client/src/hooks.client',
                server: 'client/src/hooks.server'
            },
            lib: 'client/src/lib',
            params: 'client/src/params',
            routes: 'client/src/routes',
            serviceWorker: 'client/src/service-worker',
            appTemplate: 'client/src/app.html',
            errorTemplate: 'client/src/error.html'
        }
	}
};

export default config;
