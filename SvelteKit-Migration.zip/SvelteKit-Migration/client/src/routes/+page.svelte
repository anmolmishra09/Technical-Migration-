<script lang="ts">
  import { onMount } from 'svelte';
  
  let message = "Welcome to SvelteKit on Replit!";
</script>

<div class="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4">
  <h1 class="text-4xl font-bold mb-4">{message}</h1>
  <p class="text-lg text-muted-foreground">The frontend has been successfully migrated to SvelteKit.</p>
</div>
