export interface CampaignData {
  "Ad Set Name": string;
  "Objective": string;
  "Budget": number;
  "Budget Type": string;
  "Amount Spent (USD)": number;
  "Result Type": string;
  "Results": number;
  "Cost per Result": number;
  "Reach": number;
  "Impressions": number;
  "Frequency": number;
  "Reporting Dates": string;
  // Computed fields
  roi?: number;
  cpa?: number;
}

export type SortField = "Amount Spent (USD)" | "Results" | "Cost per Result" | "roi";
export type SortOrder = "asc" | "desc";
