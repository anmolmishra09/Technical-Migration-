import { ArrowUpRight, ArrowDownRight, TrendingUp, DollarSign, Target, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: "up" | "down" | "neutral";
  icon?: "dollar" | "target" | "activity" | "trend";
  delay?: number;
}

export function MetricCard({ label, value, subValue, trend, icon = "activity", delay = 0 }: MetricCardProps) {
  const icons = {
    dollar: DollarSign,
    target: Target,
    activity: Activity,
    trend: TrendingUp,
  };

  const Icon = icons[icon];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="bg-card p-6 rounded-2xl border border-border shadow-sm hover:shadow-md transition-shadow group relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Icon className="w-24 h-24 transform translate-x-4 -translate-y-4" />
      </div>

      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="p-2.5 bg-primary/10 rounded-xl text-primary">
          <Icon className="w-5 h-5" />
        </div>
        {trend && (
          <div className={cn(
            "flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full",
            trend === "up" ? "text-green-600 bg-green-50" : "text-red-600 bg-red-50"
          )}>
            {trend === "up" ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
            <span>{trend === "up" ? "+12%" : "-4%"}</span>
          </div>
        )}
      </div>

      <div className="relative z-10">
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <h3 className="text-2xl font-bold text-foreground mt-1 tracking-tight">{value}</h3>
        {subValue && (
          <p className="text-xs text-muted-foreground mt-2 line-clamp-1">
            {subValue}
          </p>
        )}
      </div>
    </motion.div>
  );
}
