import { useCallback, useState } from "react";
import { Upload, FileSpreadsheet, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface UploadZoneProps {
  onFileSelect: (file: File) => Promise<void>;
}

export function UploadZone({ onFileSelect }: UploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);

      const files = e.dataTransfer.files;
      if (files && files[0]) {
        await handleFile(files[0]);
      }
    },
    [onFileSelect]
  );

  const handleFile = async (file: File) => {
    if (!file.name.endsWith(".xlsx") && !file.name.endsWith(".xls")) {
      alert("Please upload an Excel file (.xlsx or .xls)");
      return;
    }
    setIsProcessing(true);
    try {
      await onFileSelect(file);
    } catch (error) {
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await handleFile(e.target.files[0]);
    }
  };

  return (
    <div
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      className={cn(
        "relative group cursor-pointer overflow-hidden rounded-3xl border-2 border-dashed transition-all duration-300 w-full max-w-2xl mx-auto h-80 flex items-center justify-center bg-card",
        isDragging
          ? "border-primary bg-primary/5 scale-[1.02]"
          : "border-border hover:border-primary/50 hover:bg-muted/30"
      )}
    >
      <input
        type="file"
        accept=".xlsx, .xls"
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
        onChange={handleChange}
        disabled={isProcessing}
      />

      <div className="text-center space-y-4 p-8 relative z-10 pointer-events-none">
        <div className={cn(
          "w-20 h-20 mx-auto rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg",
          isDragging ? "bg-primary text-primary-foreground scale-110 rotate-3" : "bg-white border border-border text-primary"
        )}>
          {isProcessing ? (
            <Loader2 className="w-10 h-10 animate-spin" />
          ) : (
            <FileSpreadsheet className="w-10 h-10" />
          )}
        </div>
        
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-foreground">
            {isProcessing ? "Analyzing Data..." : "Drop your campaign data"}
          </h3>
          <p className="text-muted-foreground max-w-sm mx-auto">
            Drag and drop your Excel file here, or click to browse. Supports .xlsx and .xls formats.
          </p>
        </div>

        {!isProcessing && (
          <div className="pt-4">
            <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-primary text-primary-foreground font-medium text-sm shadow-lg shadow-primary/25 transition-transform group-hover:-translate-y-0.5">
              <Upload className="w-4 h-4" />
              Select File
            </span>
          </div>
        )}
      </div>

      {/* Decorative background gradients */}
      <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
    </div>
  );
}
