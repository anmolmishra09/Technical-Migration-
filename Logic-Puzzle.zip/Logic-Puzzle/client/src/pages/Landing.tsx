import { UploadZone } from "@/components/UploadZone";
import { useCampaignAnalysis } from "@/hooks/use-campaign-analysis";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

export default function Landing() {
  const { processFile } = useCampaignAnalysis();
  const [, setLocation] = useLocation();

  const handleFileSelect = async (file: File) => {
    try {
      await processFile(file);
      // In a real app we'd pass this data via context or state manager
      // For this demo, we'll store in localStorage to simulate persistence across routes
      // Note: File processing actually happens in hooks, but we need to persist state.
      // Since useCampaignAnalysis is a hook, its state is local. 
      // We will redirect to dashboard, and re-parse or use a global store in a real app.
      // For simplicity here, we assume the user stays in the same session context if we wrap App in a provider.
      // But since we don't have a global provider setup in this specific generated code block for the hook:
      // Let's just persist the file data to sessionStorage for the dashboard to pick up.
      
      const reader = new FileReader();
      reader.onload = (e) => {
        sessionStorage.setItem("campaignData", e.target?.result as string);
        setLocation("/dashboard");
      };
      reader.readAsBinaryString(file);
    } catch (error) {
      console.error("Upload failed", error);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center space-y-6 max-w-3xl mx-auto relative z-10 mb-12"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4 border border-primary/20">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
          </span>
          Campaign Intelligence V1.0
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-foreground">
          Analytics for <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600">
            Growth Marketers
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Upload your campaign export files and instantly get actionable insights, ROI analysis, and performance recommendations.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full relative z-10"
      >
        <UploadZone onFileSelect={handleFileSelect} />
      </motion.div>

      <div className="absolute bottom-8 text-center text-sm text-muted-foreground">
        <p>Supported Formats: .XLSX, .XLS • Analyzed locally in your browser</p>
      </div>
    </div>
  );
}
