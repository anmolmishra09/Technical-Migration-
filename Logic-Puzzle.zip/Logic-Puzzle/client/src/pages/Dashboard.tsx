import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { MetricCard } from "@/components/MetricCard";
import { useCampaignAnalysis } from "@/hooks/use-campaign-analysis";
import * as XLSX from "xlsx";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ScatterChart, Scatter, ZAxis, LineChart, Line, Legend 
} from "recharts";
import { motion } from "framer-motion";
import { AlertCircle, Download, FileSpreadsheet, Lightbulb, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { processedData, metrics, setRawData, avgValuePerResult, setAvgValuePerResult } = useCampaignAnalysis();
  const [loading, setLoading] = useState(true);

  // Hydrate data from session storage on mount
  useEffect(() => {
    const storedData = sessionStorage.getItem("campaignData");
    if (storedData) {
      try {
        const workbook = XLSX.read(storedData, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<any>(sheet);
        setRawData(jsonData);
      } catch (e) {
        console.error("Failed to parse stored data", e);
      }
    }
    setLoading(false);
  }, [setRawData]);

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-pulse text-primary font-medium">Loading analysis...</div>
        </div>
      </Layout>
    );
  }

  if (!metrics) {
    return (
      <Layout>
        <div className="text-center py-20 space-y-4">
          <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto" />
          <h2 className="text-2xl font-bold">No Data Found</h2>
          <p className="text-muted-foreground">Please upload a campaign file to view insights.</p>
        </div>
      </Layout>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-border shadow-xl rounded-xl">
          <p className="font-semibold text-sm mb-2">{label}</p>
          {payload.map((p: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: p.color }}>
              {p.name}: {typeof p.value === 'number' ? p.value.toLocaleString() : p.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Campaign Intelligence</h1>
          <p className="text-muted-foreground mt-1">Overview of your ad performance and ROI.</p>
        </div>
        <div className="flex items-center gap-4 bg-card p-2 rounded-xl border border-border shadow-sm">
          <div className="px-3 py-1">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-1">Avg Value / Result</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-foreground">$</span>
              <input 
                type="number" 
                value={avgValuePerResult}
                onChange={(e) => setAvgValuePerResult(Number(e.target.value))}
                className="w-20 bg-transparent border-none p-0 text-sm font-bold focus:ring-0"
              />
            </div>
          </div>
          <button 
            onClick={() => window.print()}
            className="p-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors shadow-md"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          label="Total Spend" 
          value={`$${metrics.totalSpend.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
          icon="dollar"
          delay={0}
        />
        <MetricCard 
          label="Total Results" 
          value={metrics.totalResults.toLocaleString()}
          icon="target"
          trend="up"
          delay={0.1}
        />
        <MetricCard 
          label="Average CPA" 
          value={`$${metrics.avgCPA.toFixed(2)}`}
          icon="activity"
          trend="down"
          delay={0.2}
        />
        <MetricCard 
          label="Best Campaign ROI" 
          value={`${metrics.bestCampaign.roi?.toFixed(0)}%`}
          subValue={metrics.bestCampaign["Ad Set Name"]}
          icon="trend"
          trend="up"
          delay={0.3}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="col-span-1 lg:col-span-2 bg-card p-6 rounded-2xl border border-border shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold">Spend vs. Results</h3>
            <div className="text-xs font-medium text-muted-foreground px-3 py-1 bg-muted rounded-full">Top 10 Campaigns</div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={processedData.slice(0, 10)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="Ad Set Name" hide />
                <YAxis yAxisId="left" orientation="left" stroke="#64748b" fontSize={12} />
                <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar yAxisId="left" dataKey="Amount Spent (USD)" name="Spend ($)" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="Results" name="Results" fill="hsl(215 25% 27%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="col-span-1 bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-6 rounded-2xl shadow-xl flex flex-col relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl -ml-16 -mb-16"></div>
          
          <div className="flex items-center gap-2 mb-6 relative z-10">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
              <Lightbulb className="w-5 h-5 text-yellow-300" />
            </div>
            <h3 className="text-lg font-bold">AI Insights</h3>
          </div>

          <div className="space-y-4 flex-1 overflow-y-auto relative z-10 pr-2 custom-scrollbar">
            {metrics.avgCPA > 20 && (
              <div className="p-4 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm">
                <p className="text-sm font-medium text-red-200 mb-1">High CPA Alert</p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Average CPA is ${metrics.avgCPA.toFixed(2)}, which is above the target threshold. Consider pausing {metrics.worstCampaign["Ad Set Name"]}.
                </p>
              </div>
            )}
            
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm">
              <p className="text-sm font-medium text-green-200 mb-1">Efficiency Star</p>
              <p className="text-xs text-slate-300 leading-relaxed">
                "{metrics.bestCampaign["Ad Set Name"]}" is your top performer with {metrics.bestCampaign.roi?.toFixed(0)}% ROI. Increase budget here.
              </p>
            </div>

            <div className="p-4 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm">
              <p className="text-sm font-medium text-blue-200 mb-1">Volume Leader</p>
              <p className="text-xs text-slate-300 leading-relaxed">
                The campaign driving the most volume is getting results at ${((metrics.bestCampaign["Amount Spent (USD)"] || 0) / (metrics.bestCampaign["Results"] || 1)).toFixed(2)} per result.
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
         <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-card p-6 rounded-2xl border border-border shadow-sm"
          >
            <h3 className="text-lg font-bold mb-6">Efficiency Matrix (Spend vs Results)</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis type="number" dataKey="Amount Spent (USD)" name="Spend" unit="$" stroke="#64748b" fontSize={12} />
                  <YAxis type="number" dataKey="Results" name="Results" stroke="#64748b" fontSize={12} />
                  <ZAxis type="number" dataKey="roi" range={[50, 400]} name="ROI" />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomTooltip />} />
                  <Scatter name="Campaigns" data={processedData} fill="hsl(var(--primary))" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="bg-card p-6 rounded-2xl border border-border shadow-sm"
          >
            <h3 className="text-lg font-bold mb-6">ROI Trends</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={processedData.slice(0, 20)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                  <XAxis dataKey="Reporting Dates" hide />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="roi" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={3}
                    dot={{ r: 4, fill: "hsl(var(--primary))" }}
                    activeDot={{ r: 6 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
      </div>
    </Layout>
  );
}
