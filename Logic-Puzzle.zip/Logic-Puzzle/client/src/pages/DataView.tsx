import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { useCampaignAnalysis } from "@/hooks/use-campaign-analysis";
import * as XLSX from "xlsx";
import { cn } from "@/lib/utils";
import { Search, Download, Trash2, ArrowUpDown } from "lucide-react";

export default function DataView() {
  const { processedData, setRawData } = useCampaignAnalysis();
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);

  useEffect(() => {
    const storedData = sessionStorage.getItem("campaignData");
    if (storedData) {
      try {
        const workbook = XLSX.read(storedData, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<any>(sheet);
        setRawData(jsonData);
      } catch (e) {
        console.error("Failed to parse stored data", e);
      }
    }
    setLoading(false);
  }, [setRawData]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const filteredData = processedData
    .filter(row => 
      row["Ad Set Name"].toLowerCase().includes(searchTerm.toLowerCase()) ||
      row["Objective"].toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (!sortConfig) return 0;
      const aValue = a[sortConfig.key as keyof typeof a];
      const bValue = b[sortConfig.key as keyof typeof b];

      if (aValue === undefined) return 1;
      if (bValue === undefined) return -1;

      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });

  if (loading) return null;

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Raw Data</h1>
          <p className="text-muted-foreground mt-1">
            View, filter, and analyze your raw campaign metrics.
          </p>
        </div>
        
        <div className="flex items-center gap-3">
           <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
             <input 
               type="text" 
               placeholder="Search campaigns..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="pl-9 pr-4 py-2 bg-white border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 w-64"
             />
           </div>
           <button 
             className="p-2 bg-white border border-border rounded-lg hover:bg-muted text-muted-foreground transition-colors"
             onClick={() => sessionStorage.removeItem("campaignData")}
           >
             <Trash2 className="w-4 h-4" />
           </button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden flex flex-col max-h-[70vh]">
        <div className="overflow-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-muted/50 sticky top-0 z-10 backdrop-blur-md">
              <tr>
                {[
                  "Ad Set Name", 
                  "Amount Spent (USD)", 
                  "Results", 
                  "Cost per Result", 
                  "ROI", 
                  "Reach", 
                  "Impressions"
                ].map((header) => (
                  <th 
                    key={header} 
                    className="px-6 py-4 font-semibold cursor-pointer hover:text-foreground transition-colors group select-none"
                    onClick={() => handleSort(header === "ROI" ? "roi" : header)}
                  >
                    <div className="flex items-center gap-1">
                      {header}
                      <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-50" />
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-muted-foreground">
                    No matching campaigns found.
                  </td>
                </tr>
              ) : (
                filteredData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-muted/30 transition-colors group">
                    <td className="px-6 py-4 font-medium text-foreground max-w-xs truncate" title={row["Ad Set Name"]}>
                      {row["Ad Set Name"]}
                    </td>
                    <td className="px-6 py-4">
                      ${row["Amount Spent (USD)"].toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-6 py-4">
                      {row["Results"].toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                      ${row["Cost per Result"].toFixed(2)}
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "inline-flex items-center px-2 py-1 rounded-md text-xs font-medium",
                        (row.roi || 0) > 100 
                          ? "bg-green-50 text-green-700 border border-green-200" 
                          : (row.roi || 0) < 0 
                            ? "bg-red-50 text-red-700 border border-red-200"
                            : "bg-blue-50 text-blue-700 border border-blue-200"
                      )}>
                        {(row.roi || 0).toFixed(0)}%
                      </span>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      {row["Reach"].toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      {row["Impressions"].toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t border-border bg-muted/10 text-xs text-muted-foreground flex justify-between items-center">
          <span>Showing {filteredData.length} campaigns</span>
          <span>Double-click a cell to edit (coming soon)</span>
        </div>
      </div>
    </Layout>
  );
}
