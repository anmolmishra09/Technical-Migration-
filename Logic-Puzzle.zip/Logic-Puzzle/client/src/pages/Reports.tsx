import { Layout } from "@/components/Layout";
import { FileText, Download, Share2, Clock } from "lucide-react";

export default function Reports() {
  const reports = [
    { id: 1, title: "Q3 Performance Review", date: "Oct 1, 2024", type: "PDF" },
    { id: 2, title: "Black Friday Campaign Analysis", date: "Dec 5, 2024", type: "Excel" },
    { id: 3, title: "Monthly ROI Report - September", date: "Sep 30, 2024", type: "PDF" },
  ];

  return (
    <Layout>
       <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Saved Reports</h1>
          <p className="text-muted-foreground mt-1">
            Access your previously generated analysis and exports.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reports.map((report) => (
            <div key={report.id} className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-all duration-300 group cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-primary/10 rounded-lg text-primary">
                  <FileText className="w-6 h-6" />
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 hover:bg-muted rounded-full text-muted-foreground hover:text-foreground">
                    <Share2 className="w-4 h-4" />
                  </button>
                  <button className="p-2 hover:bg-muted rounded-full text-muted-foreground hover:text-foreground">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              <h3 className="font-bold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
                {report.title}
              </h3>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-4">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {report.date}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-muted border border-border text-xs font-medium">
                  {report.type}
                </span>
              </div>
            </div>
          ))}
          
          <div className="bg-muted/30 border-2 border-dashed border-muted-foreground/20 rounded-xl p-6 flex flex-col items-center justify-center text-center gap-3 hover:bg-muted/50 transition-colors cursor-pointer group">
             <div className="p-3 bg-muted rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
               <FileText className="w-6 h-6 text-muted-foreground group-hover:text-primary" />
             </div>
             <div>
               <h3 className="font-semibold text-foreground">Create New Report</h3>
               <p className="text-sm text-muted-foreground">Customize metrics and export</p>
             </div>
          </div>
        </div>
    </Layout>
  );
}
