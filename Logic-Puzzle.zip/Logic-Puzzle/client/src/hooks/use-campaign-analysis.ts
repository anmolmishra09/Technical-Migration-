import { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { CampaignData } from '@/lib/types';

export function useCampaignAnalysis() {
  const [rawData, setRawData] = useState<CampaignData[]>([]);
  const [avgValuePerResult, setAvgValuePerResult] = useState<number>(50);
  const [isProcessing, setIsProcessing] = useState(false);

  const processFile = async (file: File) => {
    setIsProcessing(true);
    return new Promise<void>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json<CampaignData>(sheet);
          setRawData(jsonData);
          resolve();
        } catch (err) {
          reject(err);
        } finally {
          setIsProcessing(false);
        }
      };
      reader.onerror = (err) => {
        setIsProcessing(false);
        reject(err);
      };
      reader.readAsBinaryString(file);
    });
  };

  const processedData = useMemo(() => {
    return rawData.map(campaign => {
      const spend = Number(campaign["Amount Spent (USD)"]) || 0;
      const results = Number(campaign["Results"]) || 0;
      
      // ROI Formula: ((Results * AverageValue) - Amount Spent) / Amount Spent
      // Handle division by zero
      const revenue = results * avgValuePerResult;
      const roi = spend > 0 ? ((revenue - spend) / spend) * 100 : 0;
      
      const cpa = results > 0 ? spend / results : 0;

      return {
        ...campaign,
        "Amount Spent (USD)": spend,
        "Results": results,
        roi,
        cpa
      };
    });
  }, [rawData, avgValuePerResult]);

  const metrics = useMemo(() => {
    if (processedData.length === 0) return null;

    const totalSpend = processedData.reduce((acc, curr) => acc + (curr["Amount Spent (USD)"] || 0), 0);
    const totalResults = processedData.reduce((acc, curr) => acc + (curr["Results"] || 0), 0);
    const avgCPA = totalResults > 0 ? totalSpend / totalResults : 0;
    
    // Sort for best/worst
    const sortedByROI = [...processedData].sort((a, b) => (b.roi || 0) - (a.roi || 0));
    const bestCampaign = sortedByROI[0];
    const worstCampaign = sortedByROI[sortedByROI.length - 1];

    return {
      totalSpend,
      totalResults,
      avgCPA,
      bestCampaign,
      worstCampaign
    };
  }, [processedData]);

  return {
    rawData,
    processedData,
    metrics,
    processFile,
    isProcessing,
    avgValuePerResult,
    setAvgValuePerResult
  };
}
