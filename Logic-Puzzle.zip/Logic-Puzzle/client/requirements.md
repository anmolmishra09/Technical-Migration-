## Packages
xlsx | Parsing Excel files in the browser
recharts | Data visualization (bar charts, scatter plots, line charts)
framer-motion | Smooth page transitions and animations
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
The app processes Excel files client-side using `xlsx`.
No complex backend API is required for the analysis itself, but we will mock structure for potential future saving.
The dashboard layout should be responsive and dashboard-like with a sidebar.
Using a professional blue/gray palette suitable for data analysis.
